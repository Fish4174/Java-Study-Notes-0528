package PetPark;

public abstract class Pet
{
    private int index;//编号
    private static int count = 0;//记录宠物个数
    private String name;
    private int health;
    private int love;
    public Pet()
    {
        index = ++count;
        name = "";
        health = 60;
        love = 60;
    }
    public Pet(String name)
    {
        index = ++count;
        this.name = name;
        health = 60;
        love = 60;
    }
    public Pet(String name, int health, int love)
    {
        index = ++count;
        this.name = name;
        this.health = health;
        this.love = love;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public int getHealth()
    {
        return health;
    }
    public void setHealth(int health)
    {
        this.health = health;
    }
    public int getLove()
    {
        return love;
    }
    public void setLove(int love)
    {
        this.love = love;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void print()
    {
        System.out.println("编号：" + index);
        System.out.println("昵称：" + name);
        System.out.println("健康值：" + health);
        System.out.println("亲密度：" + love);
    }
    //设置抽象方法：吃饭方法，没有方法体，方法用abstract声明
    //抽象方法必须在子类中实现
    public abstract void eat();
}
