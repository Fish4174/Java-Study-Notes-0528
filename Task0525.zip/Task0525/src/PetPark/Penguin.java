package PetPark;

public class Penguin extends Pet
{
    private String sex;
    public Penguin()
    {
        super();
        sex = "";
    }
    public Penguin(String name)
    {
        super(name);
        sex = "";
    }
    public Penguin(String name, int health, int love, String sex)
    {
        super(name, health, love);
        this.sex = sex;
    }
    public String getSex()
    {
        return sex;
    }
    public void setSex(String sex)
    {
        this.sex = sex;
    }
    @Override
    public void print()
    {
        System.out.println("-----企鹅的自白-----");
        super.print();
        System.out.println("性别：" + sex);
        System.out.println("------------------");
    }

    @Override
    public void eat()
    {
        setHealth(getHealth()+5);
        System.out.println("企鹅" + getName() + "正在吃鱼肉……它的健康值增长到" + getHealth());
    }

    public void swimming(Master master)
    {
        System.out.println("主人" + master.getName() + "正在和编号是" + getIndex() + "的企鹅" + getName() + "游泳...");
        setHealth(getHealth()-4);
        setLove(getLove()+5);
        System.out.println("企鹅" + getName() + "的健康值减少到" + getHealth() + "，亲密度增加到" + getLove());
    }
}