package PetPark;

public class Master
{
    private String name;
    public Master(String name)
    {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void adopt(Pet pet)
    {
        System.out.println("主人" + name + "领养了宠物" + pet.getName());
    }
    public void feed(Pet pet)
    {
        pet.eat();
    }
    public void playWith(Pet pet)
    {
        if(pet instanceof Dog)
        {
            ((Dog)pet).catchingFlyDisk(this);
        }
        else
        {
            ((Penguin)pet).swimming(this);
        }
    }
}
