package PetPark;

public class Dog extends Pet
{
    private String strain;//品种
    public Dog()
    {
        super();
        strain = "";
    }
    public Dog(String name)
    {
        super(name);
        strain = "";
    }
    public Dog(String name, int health, int love, String strain)
    {
        super(name, health, love);
        this.strain = strain;
    }
    public String getStrain()
    {
        return strain;
    }
    public void setStrain(String strain)
    {
        this.strain = strain;
    }
    @Override
    public void print()
    {
        System.out.println("-----宠物狗的自白-----");
        super.print();
        System.out.println("品种：" + strain);
        System.out.println("--------------------");
    }

    @Override
    public void eat()
    {
        setHealth(getHealth()+3);
        System.out.println("小狗" + getName() + "正在吃骨头……它的健康值增长到" + getHealth());
    }

    public void catchingFlyDisk(Master master)
    {
        System.out.println("主人" + master.getName() + "正在和编号是" + getIndex() + "的宠物狗" + getName() + "玩接飞盘游戏...");
        setHealth(getHealth()-5);
        setLove(getLove()+3);
        System.out.println("宠物狗" + getName() + "的健康值减少到" + getHealth() + "，亲密度增加到" + getLove());
    }
}
