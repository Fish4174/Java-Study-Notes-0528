package PetPark;

public class PetPark
{
    public static void main(String[] args)
    {
        Pet dog = new Dog("特朗普");//用子类的构造方法创建以父之名声明的对象，本质是子类的对象
        ((Dog)dog).setStrain("金毛");//用强制类型转换，调用独属于子类的方法
        dog.print();//这里调用的是子类的方法
        //静态多态：编译时多态，通过方法重载实现
        //动态多态：运行时多态，通过方法覆盖实现
        Pet penguin = new Penguin("咕咕嘎嘎", 80, 90, "F");
        penguin.print();

        Master master1 = new Master("Tina");
        Master master2 = new Master("Tear");
        master1.adopt(dog);
        master2.adopt(penguin);
        System.out.println("----------------------");
        master1.feed(dog);
        master2.feed(penguin);
        System.out.println("----------------------");

        master1.playWith(dog);
        master2.playWith(penguin);
    }
}
