package Object;

import java.util.Objects;

public class Account
{
    String name;
    public Account(String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "姓名：" + name ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return Objects.equals(name, account.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public static void main(String[] args)
    {
        Account account = new Account("Tina");
        System.out.println(account);//自动调用toString方法
        System.out.println(account.hashCode());
        Account account2 = new Account("Tina");
        System.out.println(account2.hashCode());
        //对象相等当且仅当两个对象的成员值都相同
        int a = 1, b = 1;
        System.out.println(a == b);//true，==对于基本类型比较的是变量的值
        System.out.println(account == account2);//false，==对于引用类型比较的是对象的引用（地址）
        System.out.println(account.equals(account2));//重写前false，比较的是对象的引用（地址），重写后true
        System.out.println(account.name.hashCode() == account2.name.hashCode());
    }
}
